d3.select("body").append("div").text("Blue Circle on Beige Canvas in Dark Room");
